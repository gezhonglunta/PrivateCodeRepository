﻿namespace _MEMORY_QUERY_TOOL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_first = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.tbx_searchval_one = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_open = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.设置描述信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.复制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.复制全部ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.全部移除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbx_searchval_two = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_write = new System.Windows.Forms.Button();
            this.tbx_editvalue = new System.Windows.Forms.TextBox();
            this.btn_removelist = new System.Windows.Forms.Button();
            this.btn_addlist = new System.Windows.Forms.Button();
            this.btn_modify = new System.Windows.Forms.Button();
            this.tbx_addr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_display_ok = new System.Windows.Forms.Button();
            this.btn_display_cancel = new System.Windows.Forms.Button();
            this.tbx_displayinfo = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(12, 67);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(170, 270);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "内存地址";
            this.columnHeader1.Width = 75;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "值";
            this.columnHeader2.Width = 75;
            // 
            // btn_first
            // 
            this.btn_first.Location = new System.Drawing.Point(24, 19);
            this.btn_first.Name = "btn_first";
            this.btn_first.Size = new System.Drawing.Size(75, 23);
            this.btn_first.TabIndex = 1;
            this.btn_first.Text = "首次搜索";
            this.btn_first.UseVisualStyleBackColor = true;
            this.btn_first.Click += new System.EventHandler(this.btn_first_Click);
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(105, 19);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 23);
            this.btn_next.TabIndex = 2;
            this.btn_next.Text = "继续搜索";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // tbx_searchval_one
            // 
            this.tbx_searchval_one.Location = new System.Drawing.Point(79, 48);
            this.tbx_searchval_one.Name = "tbx_searchval_one";
            this.tbx_searchval_one.Size = new System.Drawing.Size(55, 20);
            this.tbx_searchval_one.TabIndex = 3;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(88, 74);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(90, 21);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(88, 101);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(90, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "等待搜索...";
            // 
            // btn_open
            // 
            this.btn_open.Location = new System.Drawing.Point(188, 67);
            this.btn_open.Name = "btn_open";
            this.btn_open.Size = new System.Drawing.Size(204, 23);
            this.btn_open.TabIndex = 7;
            this.btn_open.Text = "打开进程";
            this.btn_open.UseVisualStyleBackColor = true;
            this.btn_open.Click += new System.EventHandler(this.btn_open_Click);
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView2.ContextMenuStrip = this.contextMenuStrip1;
            this.listView2.FullRowSelect = true;
            this.listView2.Location = new System.Drawing.Point(12, 343);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(380, 115);
            this.listView2.TabIndex = 8;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "描述信息";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "内存地址";
            this.columnHeader4.Width = 75;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "类型";
            this.columnHeader5.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "值";
            this.columnHeader6.Width = 75;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.设置描述信息ToolStripMenuItem,
            this.复制ToolStripMenuItem,
            this.复制全部ToolStripMenuItem,
            this.全部移除ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(147, 92);
            // 
            // 设置描述信息ToolStripMenuItem
            // 
            this.设置描述信息ToolStripMenuItem.Name = "设置描述信息ToolStripMenuItem";
            this.设置描述信息ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.设置描述信息ToolStripMenuItem.Text = "设置描述信息";
            this.设置描述信息ToolStripMenuItem.Click += new System.EventHandler(this.设置描述信息ToolStripMenuItem_Click);
            // 
            // 复制ToolStripMenuItem
            // 
            this.复制ToolStripMenuItem.Name = "复制ToolStripMenuItem";
            this.复制ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.复制ToolStripMenuItem.Text = "复制";
            this.复制ToolStripMenuItem.Click += new System.EventHandler(this.复制ToolStripMenuItem_Click);
            // 
            // 复制全部ToolStripMenuItem
            // 
            this.复制全部ToolStripMenuItem.Name = "复制全部ToolStripMenuItem";
            this.复制全部ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.复制全部ToolStripMenuItem.Text = "复制全部";
            this.复制全部ToolStripMenuItem.Click += new System.EventHandler(this.复制全部ToolStripMenuItem_Click);
            // 
            // 全部移除ToolStripMenuItem
            // 
            this.全部移除ToolStripMenuItem.Name = "全部移除ToolStripMenuItem";
            this.全部移除ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.全部移除ToolStripMenuItem.Text = "全部移除";
            this.全部移除ToolStripMenuItem.Click += new System.EventHandler(this.全部移除ToolStripMenuItem_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "输入搜索值";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "搜索类型";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "数据类型";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btn_first);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_next);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbx_searchval_one);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.tbx_searchval_two);
            this.groupBox1.Location = new System.Drawing.Point(188, 96);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 131);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "搜索数据";
            // 
            // tbx_searchval_two
            // 
            this.tbx_searchval_two.Location = new System.Drawing.Point(140, 48);
            this.tbx_searchval_two.Name = "tbx_searchval_two";
            this.tbx_searchval_two.Size = new System.Drawing.Size(58, 20);
            this.tbx_searchval_two.TabIndex = 12;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_write);
            this.groupBox2.Controls.Add(this.tbx_editvalue);
            this.groupBox2.Controls.Add(this.btn_removelist);
            this.groupBox2.Controls.Add(this.btn_addlist);
            this.groupBox2.Controls.Add(this.btn_modify);
            this.groupBox2.Controls.Add(this.tbx_addr);
            this.groupBox2.Location = new System.Drawing.Point(188, 233);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(204, 104);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "操作";
            // 
            // btn_write
            // 
            this.btn_write.Location = new System.Drawing.Point(105, 45);
            this.btn_write.Name = "btn_write";
            this.btn_write.Size = new System.Drawing.Size(75, 23);
            this.btn_write.TabIndex = 5;
            this.btn_write.Text = "写入内存";
            this.btn_write.UseVisualStyleBackColor = true;
            this.btn_write.Click += new System.EventHandler(this.btn_write_Click);
            // 
            // tbx_editvalue
            // 
            this.tbx_editvalue.Location = new System.Drawing.Point(105, 19);
            this.tbx_editvalue.Name = "tbx_editvalue";
            this.tbx_editvalue.Size = new System.Drawing.Size(75, 20);
            this.tbx_editvalue.TabIndex = 4;
            // 
            // btn_removelist
            // 
            this.btn_removelist.Location = new System.Drawing.Point(105, 74);
            this.btn_removelist.Name = "btn_removelist";
            this.btn_removelist.Size = new System.Drawing.Size(90, 22);
            this.btn_removelist.TabIndex = 3;
            this.btn_removelist.Text = "移除列表";
            this.btn_removelist.UseVisualStyleBackColor = true;
            this.btn_removelist.Click += new System.EventHandler(this.btn_removelist_Click);
            // 
            // btn_addlist
            // 
            this.btn_addlist.Location = new System.Drawing.Point(9, 74);
            this.btn_addlist.Name = "btn_addlist";
            this.btn_addlist.Size = new System.Drawing.Size(90, 23);
            this.btn_addlist.TabIndex = 2;
            this.btn_addlist.Text = "加入列表";
            this.btn_addlist.UseVisualStyleBackColor = true;
            this.btn_addlist.Click += new System.EventHandler(this.btn_addlist_Click);
            // 
            // btn_modify
            // 
            this.btn_modify.Location = new System.Drawing.Point(24, 45);
            this.btn_modify.Name = "btn_modify";
            this.btn_modify.Size = new System.Drawing.Size(75, 23);
            this.btn_modify.TabIndex = 1;
            this.btn_modify.Text = "输入地址";
            this.btn_modify.UseVisualStyleBackColor = true;
            this.btn_modify.Click += new System.EventHandler(this.btn_modify_Click);
            // 
            // tbx_addr
            // 
            this.tbx_addr.Location = new System.Drawing.Point(24, 19);
            this.tbx_addr.Name = "tbx_addr";
            this.tbx_addr.ReadOnly = true;
            this.tbx_addr.Size = new System.Drawing.Size(75, 20);
            this.tbx_addr.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "当前进程: 没有选择进程";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 25);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(380, 23);
            this.progressBar1.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_display_ok);
            this.panel1.Controls.Add(this.btn_display_cancel);
            this.panel1.Controls.Add(this.tbx_displayinfo);
            this.panel1.Location = new System.Drawing.Point(12, 343);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(246, 59);
            this.panel1.TabIndex = 17;
            // 
            // btn_display_ok
            // 
            this.btn_display_ok.Location = new System.Drawing.Point(166, 29);
            this.btn_display_ok.Name = "btn_display_ok";
            this.btn_display_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_display_ok.TabIndex = 2;
            this.btn_display_ok.Text = "确定";
            this.btn_display_ok.UseVisualStyleBackColor = true;
            this.btn_display_ok.Click += new System.EventHandler(this.btn_display_ok_Click);
            // 
            // btn_display_cancel
            // 
            this.btn_display_cancel.Location = new System.Drawing.Point(85, 29);
            this.btn_display_cancel.Name = "btn_display_cancel";
            this.btn_display_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_display_cancel.TabIndex = 1;
            this.btn_display_cancel.Text = "取消";
            this.btn_display_cancel.UseVisualStyleBackColor = true;
            this.btn_display_cancel.Click += new System.EventHandler(this.btn_display_cancel_Click);
            // 
            // tbx_displayinfo
            // 
            this.tbx_displayinfo.Location = new System.Drawing.Point(3, 3);
            this.tbx_displayinfo.Name = "tbx_displayinfo";
            this.tbx_displayinfo.Size = new System.Drawing.Size(238, 20);
            this.tbx_displayinfo.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 469);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_open);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Name = "Form1";
            this.Text = "内存修改器";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btn_first;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.TextBox tbx_searchval_one;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_open;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbx_addr;
        private System.Windows.Forms.Button btn_removelist;
        private System.Windows.Forms.Button btn_addlist;
        private System.Windows.Forms.Button btn_modify;
        private System.Windows.Forms.TextBox tbx_editvalue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_write;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.TextBox tbx_searchval_two;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 设置描述信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 复制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 复制全部ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_display_ok;
        private System.Windows.Forms.Button btn_display_cancel;
        private System.Windows.Forms.TextBox tbx_displayinfo;
        private System.Windows.Forms.ToolStripMenuItem 全部移除ToolStripMenuItem;

    }
}

