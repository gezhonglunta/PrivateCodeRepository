﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;

namespace _MEMORY_QUERY_TOOL
{
    public partial class FrmOpenProcess : Form
    {
        public FrmOpenProcess() {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private Process p;
        public Process P {
            get { return p; }
        }
        Process[] ps;
        private void FrmOpenProcess_Load(object sender, EventArgs e) {
            listView1.View = View.Details;
            listView1.Columns.Add("PID");
            listView1.Columns.Add("进程名",180);
            listView1.FullRowSelect = true;
            ps = Process.GetProcesses();
            for (int i = 0; i < ps.Length; i++) {
                ListViewItem item = new ListViewItem(ps[i].Id.ToString());
                item.SubItems.Add(ps[i].ProcessName);
                listView1.Items.Add(item);
            }
            button1.Text = "确定";
            button2.Text = "取消";
        }

        private void button1_Click(object sender, EventArgs e) {
            if (listView1.SelectedItems.Count <= 0) {
                MessageBox.Show("没有选择进程!");
                return;
            }
            int index = listView1.SelectedItems[0].Index;
            p = ps[index];
            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
